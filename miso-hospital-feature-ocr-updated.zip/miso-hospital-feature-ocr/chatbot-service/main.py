"""
병원 상담 챗봇 마이크로서비스.
Node(WAS)가 세션 인증과 원문 암호화 저장을 전담하고, 이 서비스는 "질문 -> 답변"만 담당한다.
그래서 이 서비스는 DB에 접근하지 않고, 로그에도 사용자 원문을 남기지 않는다.

실행: uvicorn main:app --port 8000
"""
import json
import os
import re
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
DOCS_PATH = BASE_DIR / "hospital_documents.json"

app = FastAPI(title="Miso Hospital Chatbot Service")

# 이 서비스는 Node(WAS)에서만 호출되므로, WAS가 떠 있는 오리진만 허용한다.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("WAS_ORIGIN", "http://localhost:3000")],
    allow_methods=["POST"],
)

with open(DOCS_PATH, encoding="utf-8") as f:
    DOCUMENTS = json.load(f)

# rag-agent/audit-agent의 악의적 프롬프트 탐지 키워드를 그대로 재사용 (로깅용, 저장하지는 않음)
MALICIOUS_KEYWORDS = ["지시사항 무시", "프롬프트 출력", "시스템 프롬프트", "이전 지시 무시"]


class ChatRequest(BaseModel):
    question: str


def retrieve_best_doc(question: str) -> dict | None:
    """임베딩 없이 키워드 겹침 개수로 가장 관련 있는 문서 하나를 고르는 단순 검색.
    (원본 rag-agent는 임베딩 기반이지만, 별도 임베딩 API 키 없이도 바로 동작하도록 단순화)"""
    q_tokens = set(re.findall(r"[가-힣a-zA-Z0-9]+", question.lower()))
    best_doc, best_score = None, 0
    for doc in DOCUMENTS:
        doc_tokens = set(re.findall(r"[가-힣a-zA-Z0-9]+", doc["text"].lower()))
        score = len(q_tokens & doc_tokens)
        if score > best_score:
            best_doc, best_score = doc, score
    return best_doc if best_score > 0 else None


def generate_with_gemini(question: str, context: str) -> str | None:
    """GEMINI_API_KEY가 설정되어 있으면 실제 LLM으로 답변 생성, 없으면 None 반환(폴백 유도)."""
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        model = genai.GenerativeModel(
            model_name=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
            system_instruction=(
                "당신은 미소병원 환자 상담 챗봇입니다. 아래 제공된 병원 안내 자료(Context) "
                "범위 안에서만 한국어로 친절하고 간결하게 답합니다. Context에 없는 내용은 "
                "'정확한 안내를 위해 원무과로 문의해주세요'라고 답합니다."
            ),
        )
        prompt = f"Context:\n{context}\n\n질문: {question}"
        response = model.generate_content(prompt, generation_config={"temperature": 0.2})
        text = getattr(response, "text", None)
        return text.strip() if text else None
    except Exception as exc:  # 네트워크/키 오류 등 - 폴백으로 넘어가게 조용히 처리
        print(f"[chatbot-service] Gemini 호출 실패, 폴백 사용: {exc}")
        return None


@app.post("/chat")
def chat(req: ChatRequest):
    question = req.question.strip()

    is_suspicious = any(kw in question for kw in MALICIOUS_KEYWORDS)
    if is_suspicious:
        # 원문은 로그에 남기지 않고, 의심 이벤트가 있었다는 사실만 기록 (저장은 Node 쪽 책임)
        print("[chatbot-service] 의심스러운 프롬프트 패턴 감지됨 (내용은 로그에 남기지 않음)")

    doc = retrieve_best_doc(question)
    context = doc["text"] if doc else "관련 안내 자료를 찾지 못했습니다."

    answer = generate_with_gemini(question, context)
    if answer is None:
        # GEMINI_API_KEY가 없거나 호출 실패 시: 검색된 문서 원문을 그대로 안내하는 규칙 기반 폴백
        answer = (
            context
            if doc
            else "죄송합니다, 관련 안내를 찾지 못했습니다. 원무과(010-2222-3333)로 문의해주세요."
        )

    return {"answer": answer, "matched_doc": doc["doc_id"] if doc else None}


@app.get("/health")
def health():
    return {"status": "ok", "documents_loaded": len(DOCUMENTS)}
